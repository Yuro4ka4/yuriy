const startBtn = document.getElementById("startBtn");
const finishBtn = document.getElementById("finishBtn");
const cardsContainer = document.getElementById("cardsContainer");
const message = document.getElementById("message");
let cards = [];
let flippedCards = [];
let matchedCards = 0;
let isGameActive = false;  
let gameEnded = false;
const cardImages = [
  "image1.jpg", "image2.jpg", "image3.jpg", "image4.jpg",
  "image5.jpg", "image6.jpg", "image7.jpg", "image8.jpg"
];

function createCard(image) {
  const card = document.createElement("div");
  card.classList.add("card");

  const img = document.createElement("img");
  img.src = `images/${image}`;
  img.alt = `Card with image ${image}`;

  card.appendChild(img);
  card.setAttribute("data-image", image);

  img.onload = () => {
    console.log(`Изображение ${image} загружено успешно.`);
  };

  img.onerror = () => {
    console.error(`Ошибка при загрузке изображения ${image}.`);
  };


  card.addEventListener("click", () => flipCard(card));

  return card;
}


function shuffleCards() {
  const allCards = [...cardImages, ...cardImages];
  cards = allCards.sort(() => Math.random() - 0.5).map(createCard);
  cardsContainer.innerHTML = "";
  cards.forEach(card => cardsContainer.appendChild(card));
}


function flipCard(card) {
  console.log("Клик на карточку", card);

  if (!isGameActive) {
    console.log("Игра не активна");
    return;
  }

  if (flippedCards.length >= 2) {
    console.log("Уже перевёрнуто две карточки");
    return;
  }

  if (card.classList.contains("open")) {
    console.log("Карточка уже перевёрнута");
    return;
  }


  if (card.classList.contains("matched")) {
    console.log("Карточка уже совпала");
    return;
  }

  card.classList.add("open");

  flippedCards.push(card);
  console.log("Перевернутые карточки:", flippedCards);

  if (flippedCards.length === 2) {
    setTimeout(checkMatch, 1000); 
  }
}


function checkMatch() {
  const [card1, card2] = flippedCards;
  const img1 = card1.querySelector("img");
  const img2 = card2.querySelector("img");

  console.log("Проверка на совпадение", card1.dataset.image, card2.dataset.image);

  if (card1.dataset.image === card2.dataset.image) {
    card1.classList.add("matched");
    card2.classList.add("matched");
    img1.style.opacity = 0.5;  
    img2.style.opacity = 0.5;
    matchedCards += 2;

    console.log("Карточки совпали!");


    if (matchedCards === cards.length) {
      console.log("Игра завершена!");
      if (!gameEnded) {
        message.classList.remove("hidden");
        startBtn.textContent = "New Game";
        gameEnded = true; 
      }
    }
  } else {
  
    console.log("Карточки не совпали, переворачиваем обратно");
    card1.classList.remove("open");
    card2.classList.remove("open");
  }

  flippedCards = [];
}


function startNewGame() {
  if (gameEnded) {
    
    console.log("Начинаем новую игру");

    isGameActive = true;
    gameEnded = false;
    message.classList.add("hidden");
    matchedCards = 0;
    flippedCards = [];
    shuffleCards();
    startBtn.textContent = "New Game";
    finishBtn.classList.remove("hidden");
  } else {
    
    console.log("Игра уже активна");
  }
}

function finishGame() {
  if (!gameEnded) {
    cards.forEach(card => {
      card.classList.add("open");
      card.classList.add("matched");
      const img = card.querySelector("img");
      img.style.opacity = 1;
      img.style.visibility = "visible";
    });
    gameEnded = true;
    message.classList.remove("hidden");
    startBtn.textContent = "New Game";
    finishBtn.classList.add("hidden");
  }
}


startBtn.addEventListener("click", () => {
  if (isGameActive) {
    startNewGame(); 
  } else {
    isGameActive = true; 
    startNewGame();
  }
});

finishBtn.addEventListener("click", finishGame);


shuffleCards();
